#include "driver_state.h"
#include <cstring>
#include <iostream>
#include <cmath>
#include <limits>
#include <iostream>
driver_state::driver_state()
{
}

driver_state::~driver_state()
{
    delete [] image_color;
    delete [] image_depth;
}
int xyz(int face) { if(face <= 1) {return 0;} else if(face <= 1) {return 1;} return 2;}
// This function should allocate and initialize the arrays that store color and
// depth.  This is not done during the constructor since the width and height
// are not known when this class is constructed.
void initialize_render(driver_state& state, int width, int height)
{
    state.image_width=width;
    state.image_height=height;
    state.image_color=0;
    state.image_depth=0;
 //   std::cout<<"TODO: allocate and initialize state.image_color and state.image_depth."<<std::endl;
    state.image_color = new pixel[height * width];
    state.image_depth = new float[height * width];
    for(int i = 0; i < height * width; ++i) { 
	state.image_color[i] = make_pixel(0,0,0);
	state.image_depth[i] = std::numeric_limits<float>::max();
    }
   
}

// This function will be called to render the data that has been stored in this class.
// Valid values of type are:
//   render_type::triangle - Each group of three vertices corresponds to a triangle.
//   render_type::indexed -  Each group of three indices in index_data corresponds
//                           to a triangle.  These numbers are indices into vertex_data.
//   render_type::fan -      The vertices are to be interpreted as a triangle fan.
//   render_type::strip -    The vertices are to be interpreted as a triangle strip.
void render(driver_state& state, render_type type)
{
 //   std::cout<<"TODO: implement rendering."<<std::endl;
   int t = 0;
   int y = 1;
    switch(type) {

    case render_type::triangle:
          
             for(int i = 0; i < state.num_vertices * 
		state.floats_per_vertex; i += state.floats_per_vertex * 3) {
		  data_geometry ndc[3]; data_vertex v;
                  data_geometry vertices[3]; 
		  for(unsigned int z = 0; z < 3; ++z) {
                  	vertices[z].data = state.vertex_data + i + z * state.floats_per_vertex;
			v.data = vertices[z].data;
			ndc[z].data = vertices[z].data;
			state.vertex_shader(v,ndc[z], state.uniform_data);
			
		  }
		  const data_geometry* ras_ver[3] = {ndc, ndc + 1, ndc + 2};
		  clip_triangle(state, ras_ver,0);
             }

             break;
    case render_type::indexed:
	     for(int i = 0; i < state.num_triangles; ++i) {
		data_geometry ndc[3]; data_vertex v;
		data_geometry vertices[3];
		for(unsigned int z = 0; z < 3; ++z) {
			vertices[z].data = state.vertex_data + state.index_data[t]*state.floats_per_vertex;
			v.data = vertices[z].data;
			ndc[z].data = vertices[z].data;
			state.vertex_shader(v,ndc[z], state.uniform_data); t = t + 1;}	
		const data_geometry* ras_ver[3] = {ndc, ndc + 1, ndc +  2};
		clip_triangle(state, ras_ver,0);
	     }
             break;
    case render_type::fan:
		for(int i = 0; i < state.num_vertices - 2; ++i) {	

			data_geometry ndc[3]; data_vertex v;
			data_geometry vertices[3];
		
			for(unsigned int z = 0; z < 3; ++z) {
				if( z == 0) { vertices[z].data = state.vertex_data;}
				else {vertices[z].data = state.vertex_data + y*state.floats_per_vertex; y = y + 1;}
				v.data = vertices[z].data;
				ndc[z].data = vertices[z].data;
				state.vertex_shader(v,ndc[z], state.uniform_data);}
			y = y - 1;
			const data_geometry* ras_ver[3] = {ndc, ndc + 1, ndc + 2};
			clip_triangle(state,ras_ver,0);	
		}
		

             break;
    case render_type::strip:

             break;
    }
}


// This function clips a triangle (defined by the three vertices in the "in" array).
// It will be called recursively, once for each clipping face (face=0, 1, ..., 5) to
// clip against each of the clipping faces in turn.  When face=6, clip_triangle should
// simply pass the call on to rasterize_triangle.
void clip_triangle(driver_state& state, const data_geometry* in[3],int face)
{
    if(face==6)
    {
        rasterize_triangle(state, in);
        return;
    }
 
	int inside = 0;
	ivec3 in_out = {0,0,0};
	int j = 0; int top = 2;
	float phi = 0.0;
	float xyz_a; float xyz_b; float w_a = 1; float w_b = 1;
	if(face % 2 == 0) { w_a = -1; w_b = -1;};
	int axis = xyz(face);
	for(unsigned int i = 0; i < 3; ++i) {
		
		if( in[i]->gl_Position[axis] >= -1* in[i]->gl_Position[3] 
		&& face%2 != 0) {
			inside = inside + 1;
			in_out[j] = i; j = j + 1; 	
		}
		else if(in[i]->gl_Position[axis] <= in[i]->gl_Position[3]
		&& face%2 == 0) {
			inside = inside + 1;
			in_out[j] = i; j = j + 1;
		}	
		else { in_out[top] = i; top = top - 1;}
	}
	if(inside == 0 ) {return;}


	else if(inside == 3) {
		clip_triangle(state,in,face + 1); return;}

	else if(inside == 1 || inside == 2) {
		data_vertex perpdivide;	data_geometry vertx; data_geometry new_vertices[2];
		int d = 0;int out = 2;
			for(int l = 2;  l > 0; l = l - 1) {
				w_a = w_a* in[in_out[d]]->gl_Position[3]; w_b = w_b * in[in_out[out]]->gl_Position[3];
				xyz_a = in[in_out[d]]->gl_Position[axis]; xyz_b = in[in_out[out]]->gl_Position[axis];
		
				phi = (-w_b - xyz_b) / (xyz_a + w_a - w_b - xyz_b);
							
			
			
				float* interpolate = new float[state.floats_per_vertex];
				for(int i = 0; i < state.floats_per_vertex; ++i) {	
					interpolate[i] = phi * in[in_out[d]]->data[i] + (1 - phi) * in[in_out[out]]->data[i];
					
				}
				new_vertices[2 - l].data = interpolate;	
				perpdivide.data = new_vertices[2 - l].data;
				state.vertex_shader(perpdivide,new_vertices[2 - l],state.uniform_data);
				if(inside == 2) { d = 1;} else { out = out - 1;}
				
			}
			if( inside == 1) {
				const data_geometry* ins[3] = {in[in_out[0]], new_vertices, new_vertices + 1};
				clip_triangle(state,ins,face + 1); return;}
			else {
				data_geometry t = *in[in_out[0]]; data_geometry n = *in[in_out[1]];
				const data_geometry* ins[3] = {&t,&n,&new_vertices[0]};
				clip_triangle(state,ins,face + 1);
			        data_geometry m = *in[in_out[1]];
				const data_geometry* ind[3] = {&m,&new_vertices[0],&new_vertices[1]};
				clip_triangle(state,ind,face + 1);
				return;
			}
      }		
       
	return;
 //   std::cout<<"TODO: implement clipping. (The current code passes the triangle through without clipping them.)"<<std::endl;
}

// Rasterize the triangle defined by the three vertices in the "in" array.  This
// function is responsible for rasterization, interpolation of data to
// fragments, calling the fragment shader, and z-buffering.
void rasterize_triangle(driver_state& state, const data_geometry* in[3])
{
//    std::cout<<"TODO: implement rasterization"<<std::endl;
    data_fragment vcolor;
    data_output output;
    
    vec2 v[3]; int w = state.image_width; int h = state.image_height;
    for(int i = 0; i < 3; ++i) {
       
	v[i][0] = 0.5 * w * in[i]->gl_Position[0]/static_cast<float>(in[i]->gl_Position[3]) + ( w - 1) *0.5;   
	v[i][1] = 0.5 * h * in[i]->gl_Position[1]/static_cast<float>(in[i]->gl_Position[3])  + ( h - 1) * 0.5;
    }
	
    vec2 b = v[0]; vec2 c = v[1]; vec2 a = v[2];
    int xmin = floor(std::min(a[0],std::min(b[0],c[0])));
    if(xmin < 0) { xmin = 0;}
    int xmax = ceil(std::max(a[0],std::max(b[0],c[0])));
    if(xmax > w) { xmax = w;}	
    int ymin = floor(std::min(a[1],std::min(b[1],c[1])));
    if(ymin < 0) { ymin = 0;}
    int ymax = ceil(std::max(a[1],std::max(b[1],c[1])));
    if(ymax > h) { ymax = h;}
    float z_buff; 
    float area_triangle = ((b[0]*c[1] - c[0]*b[1]) - (a[0]*c[1] - c[0]*a[1]) + (a[0]*b[1] - b[0]*a[1]));
    float phi; float beta; float gamma; float k; float phi_; float beta_; float gamma_;
    for(int j = ymin; j <= ymax; ++j) {

	for(int i = xmin; i <= xmax; ++i) {
	
	
		phi = ((b[0]*c[1] - c[0]*b[1]) - (i*c[1] - c[0]*j) + (i*b[1] - b[0]*j)) / area_triangle;
		beta = ((i*c[1] - c[0]*j) - (a[0]*c[1]-c[0]*a[1]) + (a[0]*j - i*a[1])) / area_triangle;
		gamma = ((b[0]*j-i*b[1]) - (a[0]*j - i*a[1]) + (a[0]*b[1] - b[0]*a[1])) /  area_triangle;
		
		k = phi / in[2]->gl_Position[3] + beta / in[0]->gl_Position[3] + gamma / in[1]->gl_Position[3];		
		phi_ = phi / (in[2]->gl_Position[3] * k); beta_ = beta / (in[0]->gl_Position[3] * k); gamma_ = gamma / (in[1]->gl_Position[3] *k);
 		
		if(phi >= 0.0 && beta >= 0.0 && gamma >= 0.0) { 

			z_buff = beta * in[0]->gl_Position[2]/in[0]->gl_Position[3] + gamma * in[1]->gl_Position[2]/in[1]->gl_Position[3]
				 + phi * in[2]->gl_Position[2]/in[2]->gl_Position[3];	
			
			if( z_buff <  state.image_depth[i + w *j]) {	
			        state.image_depth[i + w*j] = z_buff;
				vcolor.data = new float[state.floats_per_vertex];
				for(int k = 0; k < state.floats_per_vertex; ++k) {
			       		  switch(state.interp_rules[k]) {
						case(interp_type::noperspective):
							vcolor.data[k] = beta * in[0]->data[k] 
							+ gamma * in[1]->data[k] + phi * in[2]->data[k];
			
						break;
						case(interp_type::flat):
							vcolor.data[k] = in[0]->data[k];
					
						break;
						case(interp_type::smooth):
							
							vcolor.data[k] = beta_ * in[0]->data[k]
							+ gamma_ * in[1]->data[k] + phi_ * in[2]->data[k];	
						break;
					  }
				  
				}
				state.fragment_shader(vcolor,output,state.uniform_data);
				state.image_color[i + w*j] = make_pixel(output.output_color[0]*255
				,output.output_color[1]*255,output.output_color[2]*255);
				
				delete [] vcolor.data;	
			}
		}
    	}
   }
  


    
}

